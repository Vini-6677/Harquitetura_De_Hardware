var searchData=
[
  ['ldr_0',['ldr',['../main_8c.html#a21cb43ac8684ff99a8a96105b104da19',1,'main.c']]],
  ['ldr_5festado_1',['ldr_estado',['../main_8c.html#a33a7637cffc21cbc5b39dba80d67a00e',1,'main.c']]],
  ['liga_5flaser_2',['liga_laser',['../main_8c.html#ac09c48cff44f99ae7d7e48356834b633',1,'main.c']]],
  ['lna_5fhcurr_3',['LNA_HCURR',['../n_r_f24_l01_8h.html#ad031c713aa7c96ca88a9710f25229495',1,'nRF24L01.h']]]
];
