var searchData=
[
  ['valor_5fldr_0',['valor_ldr',['../main_8c.html#a4bbd284d232ee5e872ea3675ea9cbc2a',1,'main.c']]],
  ['vida_1',['vida',['../main_8c.html#a83d92319ca90ef15691bb4cd7c3b8df6',1,'main.c']]]
];
