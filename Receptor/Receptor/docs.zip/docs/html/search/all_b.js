var searchData=
[
  ['observe_5ftx_0',['OBSERVE_TX',['../n_r_f24_l01_8h.html#a491468eaa7f2db84c152709b0b5fb1aa',1,'nRF24L01.h']]]
];
