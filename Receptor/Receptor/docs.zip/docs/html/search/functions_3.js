var searchData=
[
  ['ldr_0',['ldr',['../main_8c.html#a21cb43ac8684ff99a8a96105b104da19',1,'main.c']]],
  ['liga_5flaser_1',['liga_laser',['../main_8c.html#ac09c48cff44f99ae7d7e48356834b633',1,'main.c']]]
];
