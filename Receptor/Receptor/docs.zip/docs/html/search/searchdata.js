var indexSectionsWithContent =
{
  0: "_acdefgilmnoprstvw",
  1: "mnr",
  2: "cdilmnprstvw",
  3: "_acdlmprst",
  4: "acdeflmnoprstw",
  5: "adgnpr"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Ficheiros",
  2: "Funções",
  3: "Variáveis",
  4: "Macros",
  5: "Páginas"
};

