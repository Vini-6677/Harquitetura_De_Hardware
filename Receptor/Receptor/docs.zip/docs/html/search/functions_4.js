var searchData=
[
  ['main_0',['main',['../main_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main.c']]],
  ['motor_5fdesligado_1',['motor_desligado',['../main_8c.html#a1cfc4fc1b5ec87030f76ee467fba5601',1,'main.c']]],
  ['motor_5fligado_2',['motor_ligado',['../main_8c.html#aa5cf9b85b96e7c609a3abd97dde22d9f',1,'main.c']]]
];
