var searchData=
[
  ['modo_5fpenalidade_0',['modo_penalidade',['../main_8c.html#ab9853beec929fb937eee705c634c5576',1,'main.c']]]
];
