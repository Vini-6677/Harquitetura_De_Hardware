var searchData=
[
  ['read_5fpayload_0',['read_payload',['../nrf24__avr_8c.html#ac4a676257b5b86b05f4ea608636cb2cf',1,'nrf24_avr.c']]],
  ['read_5freg_1',['read_reg',['../nrf24__avr_8c.html#abefdb1d58b989853c0646a6c8b18b7d3',1,'nrf24_avr.c']]],
  ['read_5freg_5fbuf_2',['read_reg_buf',['../nrf24__avr_8c.html#a31d6889b046799ad06c03ce52c9bb640',1,'nrf24_avr.c']]]
];
