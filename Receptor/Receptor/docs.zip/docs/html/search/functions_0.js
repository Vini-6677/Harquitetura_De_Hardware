var searchData=
[
  ['ce_5fhigh_0',['ce_high',['../nrf24__avr_8c.html#a5336963072afb877d785bed84eb6b5f4',1,'nrf24_avr.c']]],
  ['ce_5flow_1',['ce_low',['../nrf24__avr_8c.html#a77c5f7c57c01266d04faea3052a47f49',1,'nrf24_avr.c']]],
  ['csn_5fhigh_2',['csn_high',['../nrf24__avr_8c.html#adaef88bc02a8e805de3b3a82bf317549',1,'nrf24_avr.c']]],
  ['csn_5flow_3',['csn_low',['../nrf24__avr_8c.html#a42f8c1120431b7c37e116a4e1eac1cc2',1,'nrf24_avr.c']]]
];
