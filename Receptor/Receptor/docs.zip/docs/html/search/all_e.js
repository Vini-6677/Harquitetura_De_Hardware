var searchData=
[
  ['setup_5faw_0',['SETUP_AW',['../n_r_f24_l01_8h.html#af5ef355ba3eca336db1285cab353ddc2',1,'nRF24L01.h']]],
  ['setup_5fretr_1',['SETUP_RETR',['../n_r_f24_l01_8h.html#a2188309b3eceeae158dd64109cd919aa',1,'nRF24L01.h']]],
  ['spi_5finit_2',['spi_init',['../nrf24__avr_8c.html#aa653f4dc3541758224a53eef3f04d490',1,'nrf24_avr.c']]],
  ['spi_5ftransfer_3',['spi_transfer',['../nrf24__avr_8c.html#a8d161d483c095113df5b69798e9cd725',1,'nrf24_avr.c']]],
  ['sprintf_5fp_4',['sprintf_P',['../_r_f24__config_8h.html#a6120d1982a91bb372fbee1502841baba',1,'RF24_config.h']]],
  ['status_5freg_5',['status_reg',['../nrf24__avr_8c.html#a7fe1e45a5bfd9d243fc5713c3a8f1bb0',1,'nrf24_avr.c']]]
];
