var searchData=
[
  ['tempo_5frotacao_0',['tempo_rotacao',['../main_8c.html#aae5f9d2bf94274c96eddc87e9480ed44',1,'main.c']]]
];
