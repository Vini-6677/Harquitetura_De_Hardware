var searchData=
[
  ['setup_5faw_0',['SETUP_AW',['../n_r_f24_l01_8h.html#af5ef355ba3eca336db1285cab353ddc2',1,'nRF24L01.h']]],
  ['setup_5fretr_1',['SETUP_RETR',['../n_r_f24_l01_8h.html#a2188309b3eceeae158dd64109cd919aa',1,'nRF24L01.h']]],
  ['sprintf_5fp_2',['sprintf_P',['../_r_f24__config_8h.html#a6120d1982a91bb372fbee1502841baba',1,'RF24_config.h']]]
];
