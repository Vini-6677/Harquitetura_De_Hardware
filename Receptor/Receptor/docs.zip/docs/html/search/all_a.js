var searchData=
[
  ['nrf24_5favailable_0',['nrf24_available',['../nrf24__avr_8c.html#a0f64caa74329fd5799a33f30bd8ebf82',1,'nrf24_available(void):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a0f64caa74329fd5799a33f30bd8ebf82',1,'nrf24_available(void):&#160;nrf24_avr.c']]],
  ['nrf24_5favr_2ec_1',['nrf24_avr.c',['../nrf24__avr_8c.html',1,'']]],
  ['nrf24_5favr_2ed_2',['nrf24_avr.d',['../nrf24__avr_8d.html',1,'']]],
  ['nrf24_5favr_2eh_3',['nrf24_avr.h',['../nrf24__avr_8h.html',1,'']]],
  ['nrf24_5fbegin_4',['nrf24_begin',['../nrf24__avr_8c.html#ab6fb4c1aa834152310116e7dec65d8e3',1,'nrf24_begin(uint8_t ce_pin, uint8_t csn_pin, uint32_t spi_speed_hz):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#ab6fb4c1aa834152310116e7dec65d8e3',1,'nrf24_begin(uint8_t ce_pin, uint8_t csn_pin, uint32_t spi_speed_hz):&#160;nrf24_avr.c']]],
  ['nrf24_5fflush_5frx_5',['nrf24_flush_rx',['../nrf24__avr_8c.html#a9351c150d32184a95db9ab4a802ed860',1,'nrf24_flush_rx(void):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a9351c150d32184a95db9ab4a802ed860',1,'nrf24_flush_rx(void):&#160;nrf24_avr.c']]],
  ['nrf24_5fflush_5ftx_6',['nrf24_flush_tx',['../nrf24__avr_8c.html#a617ab4b2604d6f482796e35da85369ad',1,'nrf24_flush_tx(void):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a617ab4b2604d6f482796e35da85369ad',1,'nrf24_flush_tx(void):&#160;nrf24_avr.c']]],
  ['nrf24_5fgetstatus_7',['nrf24_getStatus',['../nrf24__avr_8c.html#a9a23f602a6077c795322702d0a42f48c',1,'nrf24_getStatus(void):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a9a23f602a6077c795322702d0a42f48c',1,'nrf24_getStatus(void):&#160;nrf24_avr.c']]],
  ['nrf24_5finit_5fhwspi_8',['nrf24_init_hwspi',['../nrf24__avr_8c.html#a023289d1e49bf7f3b61e0e1c5312c8cf',1,'nrf24_init_hwspi(void):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a023289d1e49bf7f3b61e0e1c5312c8cf',1,'nrf24_init_hwspi(void):&#160;nrf24_avr.c']]],
  ['nrf24_5fopenreadingpipe_9',['nrf24_openReadingPipe',['../nrf24__avr_8c.html#a5af2f11537aed8a56d8489355af0ff16',1,'nrf24_openReadingPipe(uint8_t pipe, const uint8_t *address):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a5af2f11537aed8a56d8489355af0ff16',1,'nrf24_openReadingPipe(uint8_t pipe, const uint8_t *address):&#160;nrf24_avr.c']]],
  ['nrf24_5fopenwritingpipe_10',['nrf24_openWritingPipe',['../nrf24__avr_8c.html#a21d638882f746748de35324bdc21f448',1,'nrf24_openWritingPipe(const uint8_t *address):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a21d638882f746748de35324bdc21f448',1,'nrf24_openWritingPipe(const uint8_t *address):&#160;nrf24_avr.c']]],
  ['nrf24_5fread_11',['nrf24_read',['../nrf24__avr_8c.html#aa0767db791fc0b45ebadab011c1900bf',1,'nrf24_read(void *buf, uint8_t len):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#aa0767db791fc0b45ebadab011c1900bf',1,'nrf24_read(void *buf, uint8_t len):&#160;nrf24_avr.c']]],
  ['nrf24_5fsetchannel_12',['nrf24_setChannel',['../nrf24__avr_8c.html#a49aa88b1042d6d62114cfbca271d9e2b',1,'nrf24_setChannel(uint8_t channel):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a49aa88b1042d6d62114cfbca271d9e2b',1,'nrf24_setChannel(uint8_t channel):&#160;nrf24_avr.c']]],
  ['nrf24_5fsetpayloadsize_13',['nrf24_setPayloadSize',['../nrf24__avr_8c.html#aaf2900e7932ebbf7f0ecdc6bce5840e1',1,'nrf24_setPayloadSize(uint8_t size):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#aaf2900e7932ebbf7f0ecdc6bce5840e1',1,'nrf24_setPayloadSize(uint8_t size):&#160;nrf24_avr.c']]],
  ['nrf24_5fstartlistening_14',['nrf24_startListening',['../nrf24__avr_8c.html#a71c5628e9583f6a6fd0871b3ae1bf6df',1,'nrf24_startListening(void):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a71c5628e9583f6a6fd0871b3ae1bf6df',1,'nrf24_startListening(void):&#160;nrf24_avr.c']]],
  ['nrf24_5fstoplistening_15',['nrf24_stopListening',['../nrf24__avr_8c.html#a33899bc3c0f4d2293f37c306d0b8e297',1,'nrf24_stopListening(void):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a33899bc3c0f4d2293f37c306d0b8e297',1,'nrf24_stopListening(void):&#160;nrf24_avr.c']]],
  ['nrf24_5fwrite_16',['nrf24_write',['../nrf24__avr_8c.html#a8232e1982aabc6f52408c318402cb578',1,'nrf24_write(const void *buf, uint8_t len):&#160;nrf24_avr.c'],['../nrf24__avr_8h.html#a8232e1982aabc6f52408c318402cb578',1,'nrf24_write(const void *buf, uint8_t len):&#160;nrf24_avr.c']]],
  ['nrf24l01_17',['Projeto Receptor NRF24L01',['../index.html',1,'']]],
  ['nrf24l01_2eh_18',['nRF24L01.h',['../n_r_f24_l01_8h.html',1,'']]],
  ['nrf_5fconfig_19',['NRF_CONFIG',['../n_r_f24_l01_8h.html#ab365e330ce094a191c25fdf1d3f64a94',1,'nRF24L01.h']]],
  ['nrf_5fstatus_20',['NRF_STATUS',['../n_r_f24_l01_8h.html#a62c8d1dc6bd80fb70c17ef9de6d49cd2',1,'nRF24L01.h']]]
];
