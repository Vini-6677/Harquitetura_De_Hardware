var searchData=
[
  ['dynamic_5fpayloads_0',['dynamic_payloads',['../nrf24__avr_8c.html#a41244788e3cbede528185aca2e752059',1,'nrf24_avr.c']]]
];
