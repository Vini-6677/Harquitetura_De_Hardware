var searchData=
[
  ['ldr_5festado_0',['ldr_estado',['../main_8c.html#a33a7637cffc21cbc5b39dba80d67a00e',1,'main.c']]]
];
