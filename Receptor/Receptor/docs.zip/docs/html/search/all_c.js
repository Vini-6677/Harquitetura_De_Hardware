var searchData=
[
  ['payload_5fsize_0',['payload_size',['../nrf24__avr_8c.html#a65f255eac5ac95eac87265229309fa60',1,'nrf24_avr.c']]],
  ['pinmode_5fd_1',['pinMode_d',['../nrf24__avr_8c.html#aa3db4917fa58896ce0a8027a30795033',1,'nrf24_avr.c']]],
  ['pll_5flock_2',['PLL_LOCK',['../n_r_f24_l01_8h.html#af76cfc0d6ed71259b4a237cbd8e30624',1,'nRF24L01.h']]],
  ['plos_5fcnt_3',['PLOS_CNT',['../n_r_f24_l01_8h.html#af45c13e8941613c7eb931001ab964965',1,'nRF24L01.h']]],
  ['prim_5frx_4',['PRIM_RX',['../n_r_f24_l01_8h.html#a0b4d92f3ecccb150d4cb1cb5d0f9d4e6',1,'nRF24L01.h']]],
  ['projeto_20receptor_20nrf24l01_5',['Projeto Receptor NRF24L01',['../index.html',1,'']]],
  ['pwr_5fup_6',['PWR_UP',['../n_r_f24_l01_8h.html#af0dbd9e4c17ba0db357fcb2cedd4aa6d',1,'nRF24L01.h']]]
];
