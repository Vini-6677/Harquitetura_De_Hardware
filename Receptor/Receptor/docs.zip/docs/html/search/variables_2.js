var searchData=
[
  ['contador_5fpenalidade_0',['contador_penalidade',['../main_8c.html#ae4f6e30ca7d74f01452759edd52f4902',1,'main.c']]]
];
