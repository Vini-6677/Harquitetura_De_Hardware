var main_8c =
[
    [ "CE_PIN", "main_8c.html#abb388c9dfbdca89b280a12c4af1a030f", null ],
    [ "CSN_PIN", "main_8c.html#a6c4d73944fe1bd2ff7ceee867c315ac1", null ],
    [ "F_CPU", "main_8c.html#a43bafb28b29491ec7f871319b5a3b2f8", null ],
    [ "ISR", "main_8c.html#ad39420cdd896dd12c68e36313139d0a5", null ],
    [ "ldr", "main_8c.html#a21cb43ac8684ff99a8a96105b104da19", null ],
    [ "liga_laser", "main_8c.html#ac09c48cff44f99ae7d7e48356834b633", null ],
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "motor_desligado", "main_8c.html#a1cfc4fc1b5ec87030f76ee467fba5601", null ],
    [ "motor_ligado", "main_8c.html#aa5cf9b85b96e7c609a3abd97dde22d9f", null ],
    [ "timer1_laser", "main_8c.html#afb288ea292f14c0fe3804f633abf6378", null ],
    [ "valor_ldr", "main_8c.html#a4bbd284d232ee5e872ea3675ea9cbc2a", null ],
    [ "vida", "main_8c.html#a83d92319ca90ef15691bb4cd7c3b8df6", null ],
    [ "contador_penalidade", "main_8c.html#ae4f6e30ca7d74f01452759edd52f4902", null ],
    [ "ldr_estado", "main_8c.html#a33a7637cffc21cbc5b39dba80d67a00e", null ],
    [ "modo_penalidade", "main_8c.html#ab9853beec929fb937eee705c634c5576", null ],
    [ "rxaddr", "main_8c.html#adfa69aeede6b90a7fb8c211a9cf16858", null ],
    [ "tempo_rotacao", "main_8c.html#aae5f9d2bf94274c96eddc87e9480ed44", null ]
];