var indexSectionsWithContent =
{
  0: "_acdefglmnoprstw",
  1: "mnr",
  2: "acdgmnprsw",
  3: "_adpst",
  4: "acdeflmnoprstw",
  5: "adgnpt"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Ficheiros",
  2: "Funções",
  3: "Variáveis",
  4: "Macros",
  5: "Páginas"
};

