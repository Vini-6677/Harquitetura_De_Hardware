var searchData=
[
  ['geral_0',['Descrição Geral',['../index.html#descricao',1,'']]],
  ['get_5fcmd_1',['get_cmd',['../main_8c.html#aa326308cba48a8a9f67e5f687b4bebb8',1,'main.c']]]
];
