var searchData=
[
  ['autor_0',['Autor',['../index.html#autor',1,'']]]
];
