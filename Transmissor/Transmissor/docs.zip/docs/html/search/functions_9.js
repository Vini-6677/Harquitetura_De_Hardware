var searchData=
[
  ['write_5fpayload_0',['write_payload',['../nrf24__avr_8c.html#a3c9fd94e9894bf0792d4ff5891c16436',1,'nrf24_avr.c']]],
  ['write_5freg_1',['write_reg',['../nrf24__avr_8c.html#a08bc978021db604d02a6da754f73e7e2',1,'nrf24_avr.c']]]
];
