var searchData=
[
  ['status_5freg_0',['status_reg',['../nrf24__avr_8c.html#a7fe1e45a5bfd9d243fc5713c3a8f1bb0',1,'nrf24_avr.c']]]
];
