var searchData=
[
  ['spi_5finit_0',['spi_init',['../nrf24__avr_8c.html#aa653f4dc3541758224a53eef3f04d490',1,'nrf24_avr.c']]],
  ['spi_5ftransfer_1',['spi_transfer',['../nrf24__avr_8c.html#a8d161d483c095113df5b69798e9cd725',1,'nrf24_avr.c']]]
];
