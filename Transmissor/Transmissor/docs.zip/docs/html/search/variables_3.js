var searchData=
[
  ['payload_5fsize_0',['payload_size',['../nrf24__avr_8c.html#a65f255eac5ac95eac87265229309fa60',1,'nrf24_avr.c']]]
];
