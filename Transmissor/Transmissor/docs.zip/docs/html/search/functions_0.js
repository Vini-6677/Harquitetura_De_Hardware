var searchData=
[
  ['adc_5ffrente_5ftras_5fy_0',['adc_frente_tras_y',['../main_8c.html#a4201d260ba828be06c924b893f41edce',1,'main.c']]],
  ['adc_5fvalor_1',['adc_valor',['../main_8c.html#abeb5aa3150defef2187914fe961ce6d7',1,'main.c']]]
];
