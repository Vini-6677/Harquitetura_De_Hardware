var searchData=
[
  ['get_5fcmd_0',['get_cmd',['../main_8c.html#aa326308cba48a8a9f67e5f687b4bebb8',1,'main.c']]]
];
