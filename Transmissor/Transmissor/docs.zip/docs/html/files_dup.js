var files_dup =
[
    [ "Debug", "dir_faa8bedbcbaa373d57b77d9219afda20.html", "dir_faa8bedbcbaa373d57b77d9219afda20" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "nrf24_avr.c", "nrf24__avr_8c.html", "nrf24__avr_8c" ],
    [ "nrf24_avr.h", "nrf24__avr_8h.html", "nrf24__avr_8h" ],
    [ "nRF24L01.h", "n_r_f24_l01_8h.html", "n_r_f24_l01_8h" ],
    [ "RF24_config.h", "_r_f24__config_8h.html", "_r_f24__config_8h" ]
];