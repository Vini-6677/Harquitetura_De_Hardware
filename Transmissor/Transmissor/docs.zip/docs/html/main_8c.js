var main_8c =
[
    [ "CE_PIN", "main_8c.html#abb388c9dfbdca89b280a12c4af1a030f", null ],
    [ "CSN_PIN", "main_8c.html#a6c4d73944fe1bd2ff7ceee867c315ac1", null ],
    [ "F_CPU", "main_8c.html#a43bafb28b29491ec7f871319b5a3b2f8", null ],
    [ "adc_frente_tras_y", "main_8c.html#a4201d260ba828be06c924b893f41edce", null ],
    [ "adc_valor", "main_8c.html#abeb5aa3150defef2187914fe961ce6d7", null ],
    [ "get_cmd", "main_8c.html#aa326308cba48a8a9f67e5f687b4bebb8", null ],
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "txaddr", "main_8c.html#ac60e1594b3a8b3a2984785a2ca4e1f33", null ]
];